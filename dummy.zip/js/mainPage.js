$(document).ready(function () {
    $(".header").height($(window).height());
});
